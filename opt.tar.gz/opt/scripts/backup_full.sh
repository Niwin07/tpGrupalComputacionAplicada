#!/bin/bash

# Opcion de ayuda
if [ "$1" == "-help" ]; then
    echo "uso: backup_full.sh <origen> <destino>"
    echo "ejemplo: backup_full.sh /var/log /backup_dir"
    echo "  origen:  directorio a backupear"
    echo "  destino: directorio donde guardar el backup"
    exit 0
fi

# Validar argumentos
if [ -z "$1" ] || [ -z "$2" ]; then
    echo "error: debe indicar origen y destino"
    echo "use -help para mas informacion"
    exit 1
fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)

# Validar que origen existe y esta montado
if [ ! -d "$ORIGEN" ]; then
    echo "error: el directorio origen $ORIGEN no existe o no esta disponible"
    exit 1
fi

# Validar que destino existe y esta montado
if [ ! -d "$DESTINO" ]; then
    echo "error: el directorio destino $DESTINO no existe o no esta disponible"
    exit 1
fi

# Ejecutar backup
tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"

if [ $? -eq 0 ]; then
    echo "backup exitoso: $DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"
else
    echo "error al crear el backup"
    exit 1
fi
